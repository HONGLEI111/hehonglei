---
title: My first Post
date: 2024-07-23 11:44:33
cover: https://img.hehonglei.cn/img/0004.jpg
tags:
  - 软件
  - Mailbird
  - 邮箱
  - 推荐
  - PC
categories:
  - original 
  - software
  - PC 
---
这是第一行；


<table>
    <tr>
        <td>移动光标的方法 </td>
        <td></td>
    </tr>
    <tr>
        <td>h 或 向左箭头键(←)</td>
        <td>光标向左移动一个字符 </td>
    </tr>
    <tr>
        <td>j 或 向下箭头键(↓)</td>
        <td>光标向下移动一个字符 </td>
    </tr>
    <tr>
        <td>k 或 向上箭头键(↑)</td>
        <td>光标向上移动一个字符 </td>
    </tr>
    <tr>
        <td>l 或 向右箭头键(→)</td>
        <td>光标向右移动一个字符 </td>
    </tr>
    <tr>
        <td>如果你将右手放在键盘上的话，你会发现 hjkl 是排列在一起的，因此可以使用这四个按钮来移动光标。 如果想要进行多次移动的话，例如向下移动 30 行，可以使用 &quot;30j&quot; 或 &quot;30↓&quot; 的组合按键， 亦即加上想要进行的次数(数字)后，按下动作即可！ </td>
        <td></td>
    </tr>
    <tr>
        <td>[Ctrl] + [f]</td>
        <td>屏幕『向下』移动一页，相当于 [Page Down]按键 (常用) </td>
    </tr>
    <tr>
        <td>[Ctrl] + [b]</td>
        <td>屏幕『向上』移动一页，相当于 [Page Up] 按键 (常用) </td>
    </tr>
    <tr>
        <td>[Ctrl] + [d]</td>
        <td>屏幕『向下』移动半页 </td>
    </tr>
    <tr>
        <td>[Ctrl] + [u]</td>
        <td>屏幕『向上』移动半页 </td>
    </tr>
    <tr>
        <td>+</td>
        <td>光标移动到非空格符的下一行 </td>
    </tr>
    <tr>
        <td>-</td>
        <td>光标移动到非空格符的上一行 </td>
    </tr>
    <tr>
        <td>n&lt;space&gt;</td>
        <td>那个 n 表示『数字』，例如 20 。按下数字后再按空格键，光标会向右移动这一行的 n 个字符。例如 20&lt;space&gt; 则光标会向后面移动 20 个字符距离。 </td>
    </tr>
    <tr>
        <td>0 或功能键[Home]</td>
        <td>这是数字『 0 』：移动到这一行的最前面字符处 (常用) </td>
    </tr>
    <tr>
        <td>$ 或功能键[End]</td>
        <td>移动到这一行的最后面字符处(常用) </td>
    </tr>
    <tr>
        <td>H</td>
        <td>光标移动到这个屏幕的最上方那一行的第一个字符 </td>
    </tr>
    <tr>
        <td>M</td>
        <td>光标移动到这个屏幕的中央那一行的第一个字符 </td>
    </tr>
    <tr>
        <td>L</td>
        <td>光标移动到这个屏幕的最下方那一行的第一个字符 </td>
    </tr>
    <tr>
        <td>G</td>
        <td>移动到这个档案的最后一行(常用) </td>
    </tr>
</table>


